# ChessArena multiplayer

A Node.js + Express + Socket.IO live chess prototype.

## Run locally
1. Install Node.js 20 or newer.
2. In this folder, run `npm install`.
3. Run `npm start`.
4. Open `http://localhost:3000` in two browser windows/devices.
5. Create a room in one and join its six-character code in the other.

Health endpoint: `/health`.

## Improvements in this revision
- Server-derived legal move destinations (including check restrictions, castling, en passant and promotions).
- Promotion picker for queen, rook, bishop or knight.
- Resignation is stored as a terminal game result and further moves are rejected.
- Room switching detaches the socket from its prior seat.
- Seat token stored in the current browser session allows reconnecting after a temporary disconnect while the server process and room remain alive.
- Input validation, safer display names, terminal game guards and a health endpoint.

## Important limits before a real public launch
This is a prototype, not a finished commercial service. Rooms and games live in server memory and disappear on server restart. Seat tokens are session-scoped and are not full user accounts. It has no durable database, account system, matchmaking, ratings, moderation, monitoring, distributed hosting adapter, or comprehensive automated test suite. Add those and run security/load tests before inviting the public. Deploying requires a hosting account and configuration; this package does not make a website live by itself.
